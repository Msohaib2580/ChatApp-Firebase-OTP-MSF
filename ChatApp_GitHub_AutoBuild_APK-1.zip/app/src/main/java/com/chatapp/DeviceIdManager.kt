package com.chatapp

import android.content.Context
import java.util.UUID

class DeviceIdManager(context: Context) {
    private val prefs = context.getSharedPreferences("chatapp_device", Context.MODE_PRIVATE)

    fun get(): String {
        val existing = prefs.getString("device_id", null)
        if (!existing.isNullOrBlank()) return existing

        val generated = UUID.randomUUID().toString()
        prefs.edit().putString("device_id", generated).apply()
        return generated
    }
}
