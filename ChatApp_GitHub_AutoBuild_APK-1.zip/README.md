# ChatApp — GitHub Ready Android Project

A starter Android messaging application with:

- Phone number login
- Firebase Phone Authentication / real SMS OTP
- OTP verification
- Persistent Firebase session
- App-generated Device ID (no IMEI)
- Home screen
- Logout
- GitHub-friendly project structure

## Requirements

- Android Studio Ladybug or newer
- Android SDK 35
- JDK 17
- A Firebase project

## Firebase setup

1. Create a Firebase project.
2. Add an Android app with package name:

   `com.chatapp`

3. Download `google-services.json`.
4. Put it at:

   `app/google-services.json`

5. In Firebase Console, enable:
   - Authentication → Sign-in method → Phone
6. Add your test phone numbers if you want Firebase test OTPs during development.
7. For production SMS OTP, configure the Firebase/Google Cloud project as required by Firebase.

## Build

Open this folder in Android Studio and let Gradle sync.

Then run the `app` configuration on an Android device or emulator.

## GitHub

Do not commit `google-services.json` if you want to keep Firebase project configuration private. The included `.gitignore` ignores it.

Suggested commands:

```bash
git init
git add .
git commit -m "Initial ChatApp Android project"
git branch -M main
git remote add origin YOUR_GITHUB_REPOSITORY_URL
git push -u origin main
```

## App flow

Country code / phone number
→ Send OTP
→ Verify OTP
→ Firebase account/session
→ Device ID registration
→ Home

## Device ID

This project creates an app-scoped random UUID and stores it in SharedPreferences. It does not read IMEI, IMSI, contacts, or other hardware identifiers.

For a production app, store the device record in Firestore after adding the Firestore SDK and your security rules.

## Important

The project is a working authentication starter, not a finished WhatsApp replacement. Chat, media upload, calls, groups, push notifications and admin features should be added as separate production modules.


## GitHub Actions — automatic APK

Every push to `main` runs the Android build and uploads the Debug APK as the `ChatApp-debug-apk` artifact. This workflow uses Java 17, Gradle 8.9, and the current Gradle Actions setup pattern. The APK is available under the successful workflow run's **Artifacts** section.

### Add Firebase secret

Because `google-services.json` is ignored by Git, add it as a repository secret:

1. Open GitHub repository → **Settings → Secrets and variables → Actions**.
2. Create a **New repository secret** named `GOOGLE_SERVICES_JSON`.
3. Open your real `google-services.json` in a text editor and paste the entire JSON into the secret value.
4. Save it.
5. Push to `main` (or use **Actions → Android APK Build → Run workflow**).

The workflow recreates `app/google-services.json` only inside the temporary GitHub runner. Do not commit the real Firebase file to the repository.

### Get the APK

After the workflow finishes successfully:

**GitHub → Actions → Android APK Build → latest successful run → Artifacts → ChatApp-debug-apk**.

This is a debug APK for testing. A production/release APK should be signed with a release keystore stored in GitHub Secrets.
